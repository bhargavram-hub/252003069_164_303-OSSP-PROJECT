#include "scheduler.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

typedef struct { int pid, arrival, burst, remaining, start, finish, waiting, response; } Job;

static void fcfs_lab(void) {
    Job j[]={{1,0,5,5,-1,0,0,0},{2,1,3,3,-1,0,0,0},{3,2,4,4,-1,0,0,0}};
    int t=0; double sw=0, st=0, sr=0;
    puts("FCFS benchmark workload: P1(AT0,BT5), P2(AT1,BT3), P3(AT2,BT4)");
    /* Preserve input order for this fixed experiment; wait until each arrival. */
    for(int i=0;i<3;i++){
        if(t<j[i].arrival)t=j[i].arrival;
        j[i].start=t; j[i].response=t-j[i].arrival;
        t+=j[i].burst; j[i].finish=t;
        j[i].waiting=j[i].start-j[i].arrival;
        sw+=j[i].waiting; st+=j[i].finish-j[i].arrival; sr+=j[i].response;
        printf("P%d start=%d finish=%d WT=%d RT=%d TAT=%d\n",j[i].pid,j[i].start,j[i].finish,j[i].waiting,j[i].response,j[i].finish-j[i].arrival);
    }
    printf("FCFS averages: WT=%.2f TAT=%.2f RT=%.2f\n",sw/3,st/3,sr/3);
}
static void rr_lab(void) {
    int rem[]={5,3,4}, arrival[]={0,1,2}, burst[]={5,3,4}, finish[3]={0}, first[3]={-1,-1,-1};
    int q[128], head=0, tail=0, t=0, quantum=2, enqueued[3]={0};
    puts("Round Robin benchmark (quantum=2)");
    while(rem[0]+rem[1]+rem[2]>0 && t<1000) {
        for(int i=0;i<3;i++) if(!enqueued[i] && arrival[i]<=t && rem[i]>0){q[tail++]=i;enqueued[i]=1;}
        if(head==tail){t++;continue;}
        int i=q[head++]; if(first[i]<0)first[i]=t;
        int run=rem[i]<quantum?rem[i]:quantum;
        printf("t=%d..%d: P%d runs\n",t,t+run,i+1);
        for(int k=0;k<run;k++){
            t++;
            for(int x=0;x<3;x++)if(!enqueued[x]&&arrival[x]<=t&&rem[x]>0){q[tail++]=x;enqueued[x]=1;}
        }
        rem[i]-=run;
        if(rem[i]==0)finish[i]=t; else q[tail++]=i;
    }
    double wt=0,tat=0,rt=0;
    for(int i=0;i<3;i++){int w=finish[i]-arrival[i]-burst[i],r=first[i]-arrival[i],ta=finish[i]-arrival[i];wt+=w;tat+=ta;rt+=r;printf("P%d CT=%d TAT=%d WT=%d RT=%d\n",i+1,finish[i],ta,w,r);}
    printf("RR averages: WT=%.2f TAT=%.2f RT=%.2f; quantum=%d\n",wt/3,tat/3,rt/3,quantum);
}
void advanced_algorithm_lab(void){fcfs_lab();rr_lab();}

void message_delivery_lab(void) {
    int attempts=0, delivered=0, dropped=0, retried=0, acked=0;
    puts("Deterministic message delivery test: 10 messages, simulated first-attempt loss for IDs 3 and 7.");
    for(int id=1;id<=10;id++){
        attempts++;
        if(id==3||id==7){
            dropped++;
            printf("SEND M%02d attempt=1 -> simulated loss; sender retains unacked message\n",id);
            attempts++; retried++;
            printf("RETRY M%02d attempt=2 -> delivered; ACK received\n",id);
            delivered++;acked++;
        }else{
            printf("SEND M%02d attempt=1 -> delivered; ACK received\n",id);
            delivered++;acked++;
        }
    }
    printf("Reliability summary: logical_messages=10 attempts=%d delivered=%d first_attempt_losses=%d retries=%d acknowledgements=%d unresolved=0\n",attempts,delivered,dropped,retried,acked);
    puts("This is a deterministic simulation of loss/retry/acknowledgement, not a real network transport.");
}
void banker_safety_lab(void) {
    int alloc[5][3]={{0,1,0},{2,0,0},{3,0,2},{2,1,1},{0,0,2}};
    int max[5][3]={{7,5,3},{3,2,2},{9,0,2},{2,2,2},{4,3,3}};
    int avail[3]={3,3,2}, need[5][3], finish[5]={0}, seq[5], count=0;
    for(int i=0;i<5;i++)for(int r=0;r<3;r++)need[i][r]=max[i][r]-alloc[i][r];
    puts("Banker's algorithm test: resource types A,B,C; available = [3,3,2]");
    int progress=1;
    while(progress){
        progress=0;
        for(int i=0;i<5;i++)if(!finish[i]){
            int ok=1;for(int r=0;r<3;r++)if(need[i][r]>avail[r])ok=0;
            if(ok){for(int r=0;r<3;r++)avail[r]+=alloc[i][r];finish[i]=1;seq[count++]=i;progress=1;}
        }
    }
    if(count==5){printf("SAFE state. Safe sequence: ");for(int i=0;i<count;i++)printf("P%d%s",seq[i],i==count-1?"\n":" -> ");}
    else {printf("UNSAFE state; unfinished processes: ");for(int i=0;i<5;i++)if(!finish[i])printf("P%d ",i);puts("");}
}
void page_replacement_lab(void) {
    int refs[]={7,0,1,2,0,3,0,4,2,3,0,3,2};int n=sizeof(refs)/sizeof(refs[0]);
    /* Correct FIFO and LRU with distinct replacement rules. */
    int fifo[3]={-1,-1,-1}, lru[3]={-1,-1,-1}, stamp[3]={0}, next=0, faultsF=0,faultsL=0;
    puts("Page reference string: 7 0 1 2 0 3 0 4 2 3 0 3 2 (3 frames)");
    for(int t=0;t<n;t++){
        int hit=0;for(int i=0;i<3;i++)if(fifo[i]==refs[t])hit=1;
        if(!hit){faultsF++;int slot=-1;for(int i=0;i<3;i++)if(fifo[i]<0){slot=i;break;}if(slot<0){slot=next;next=(next+1)%3;}fifo[slot]=refs[t];}
        hit=0;for(int i=0;i<3;i++)if(lru[i]==refs[t]){hit=1;stamp[i]=t;}
        if(!hit){faultsL++;int slot=-1;for(int i=0;i<3;i++)if(lru[i]<0){slot=i;break;}if(slot<0){slot=0;for(int i=1;i<3;i++)if(stamp[i]<stamp[slot])slot=i;}lru[slot]=refs[t];stamp[slot]=t;}
    }
    printf("FIFO page faults=%d; LRU page faults=%d\n",faultsF,faultsL);
    puts("Lower fault count is better for this reference string; results depend on workload.");
}
void export_metrics_lab(void) {
    FILE *f=fopen("experiment_summary.csv","w");
    if(!f){perror("experiment_summary.csv");return;}
    fputs("experiment,metric,value,notes\n",f);
    fputs("message_delivery,logical_messages,10,deterministic simulated workload\n",f);
    fputs("message_delivery,first_attempt_losses,2,IDs 3 and 7\n",f);
    fputs("message_delivery,retries,2,retry then acknowledged\n",f);
    fputs("round_robin,quantum,2,benchmark workload\n",f);
    fputs("page_replacement,frames,3,reference string in console output\n",f);
    fclose(f);
    puts("Wrote experiment_summary.csv");
}
