#include "scheduler.h"
#include <stdio.h>
#include <time.h>

void event_log(const char *category, const char *message, int pid, int time) {
    FILE *f = fopen("scheduler_events.log", "a");
    if (!f) return;
    fprintf(f, "t=%-5d | %-12s | PID=%-3d | %s\n",
            time, category ? category : "EVENT", pid, message ? message : "");
    fclose(f);
}
