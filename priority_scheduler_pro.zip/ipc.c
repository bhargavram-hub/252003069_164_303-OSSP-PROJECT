#include "scheduler.h"
#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <signal.h>
#include <string.h>
#include <errno.h>

void pipe_demo(void) {
    int fd[2]; char buf[128]={0};
    if(pipe(fd)<0){perror("pipe");return;}
    pid_t pid=fork();
    if(pid<0){perror("fork");close(fd[0]);close(fd[1]);return;}
    if(pid==0){close(fd[0]);const char *m="Message through anonymous pipe";write(fd[1],m,strlen(m)+1);close(fd[1]);_exit(0);}
    close(fd[1]);ssize_t n=read(fd[0],buf,sizeof(buf));close(fd[0]);waitpid(pid,NULL,0);
    if(n>0)printf("Pipe received: %s\n",buf);
}
void fifo_demo(void) {
    const char *path="/tmp/priority_scheduler_fifo";
    if(mkfifo(path,0600)<0 && errno!=EEXIST){perror("mkfifo");return;}
    pid_t pid=fork();
    if(pid<0){perror("fork");unlink(path);return;}
    if(pid==0){int fd=open(path,O_WRONLY);if(fd>=0){const char *m="Message through named FIFO";write(fd,m,strlen(m)+1);close(fd);}_exit(0);}
    char buf[128]={0};int fd=open(path,O_RDONLY);
    if(fd>=0){ssize_t n=read(fd,buf,sizeof(buf));close(fd);if(n>0)printf("FIFO received: %s\n",buf);}
    waitpid(pid,NULL,0);unlink(path);
}
static volatile sig_atomic_t got_signal;
static void usr1_handler(int sig){(void)sig;got_signal=1;}
void signal_demo(void) {
    struct sigaction sa;memset(&sa,0,sizeof(sa));sa.sa_handler=usr1_handler;sigemptyset(&sa.sa_mask);
    if(sigaction(SIGUSR1,&sa,NULL)<0){perror("sigaction");return;}
    got_signal=0;kill(getpid(),SIGUSR1);
    printf("SIGUSR1 received by handler: %s\n",got_signal?"yes":"no");
}


#define MQ_CAPACITY 3
#define MQ_MESSAGES 8
void message_queue_demo(void) {
    struct Message { int id, sender, receiver; char payload[48]; };
    struct Message q[MQ_CAPACITY];
    int head=0, count=0, sent=0, received=0, dropped=0, blocked_senders=0;
    puts("Bounded message queue capacity: 3");
    for (int i=1; i<=MQ_MESSAGES; i++) {
        if (count == MQ_CAPACITY) {
            printf("[QUEUE FULL] Sender P%d blocked; message M%d not enqueued.\n", i, i);
            blocked_senders++;
            dropped++;
            /* Receiver consumes one item, freeing a slot; sender retries. */
            struct Message old=q[head];
            printf("[RECEIVE] M%d from P%d: %s\n", old.id, old.sender, old.payload);
            head=(head+1)%MQ_CAPACITY; count--; received++;
            printf("[WAKEUP] Sender P%d resumed after queue space became available.\n", i);
        }
        int tail=(head+count)%MQ_CAPACITY;
        q[tail].id=i; q[tail].sender=i; q[tail].receiver=0;
        snprintf(q[tail].payload,sizeof(q[tail].payload),"payload-%02d",i);
        count++; sent++;
        printf("[SEND] M%d enqueued by P%d; queue occupancy=%d/%d\n",i,i,count,MQ_CAPACITY);
    }
    while(count>0) {
        struct Message old=q[head];
        printf("[RECEIVE] M%d from P%d: %s\n",old.id,old.sender,old.payload);
        head=(head+1)%MQ_CAPACITY;count--;received++;
    }
    printf("Message queue summary: sent=%d received=%d full-events=%d dropped=%d pending=%d\n",
           sent,received,blocked_senders,dropped,count);
    puts("Note: full-queue events are logged; senders retry after a receiver frees capacity.");
}
