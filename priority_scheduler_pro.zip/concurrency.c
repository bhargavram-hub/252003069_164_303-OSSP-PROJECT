#include "scheduler.h"
#include <stdio.h>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>

static long counter;
static pthread_mutex_t counter_mutex=PTHREAD_MUTEX_INITIALIZER;
static void *counter_worker(void *arg) {
    long loops=*(long *)arg;
    for(long i=0;i<loops;i++){pthread_mutex_lock(&counter_mutex);counter++;pthread_mutex_unlock(&counter_mutex);}
    return NULL;
}
void thread_demo(void) {
    pthread_t a,b;long loops=100000;counter=0;
    if(pthread_create(&a,NULL,counter_worker,&loops)!=0){perror("pthread_create");return;}
    if(pthread_create(&b,NULL,counter_worker,&loops)!=0){perror("pthread_create");pthread_join(a,NULL);return;}
    pthread_join(a,NULL);pthread_join(b,NULL);
    printf("Two threads completed; mutex-protected counter=%ld (expected %ld)\n",counter,2*loops);
}
static sem_t slots;
static void *sem_worker(void *arg) {
    int id=*(int *)arg;
    if(sem_wait(&slots)<0)return NULL;
    printf("Semaphore worker %d entered limited section.\n",id);
    usleep(50000);sem_post(&slots);return NULL;
}
void semaphore_demo(void) {
    pthread_t t[4];int ids[4]={1,2,3,4};
    if(sem_init(&slots,0,2)<0){perror("sem_init");return;}
    int created=0;
    for(int i=0;i<4;i++){if(pthread_create(&t[i],NULL,sem_worker,&ids[i])!=0){perror("pthread_create");break;}created++;}
    for(int i=0;i<created;i++)pthread_join(t[i],NULL);
    sem_destroy(&slots);puts("Semaphore demonstration finished.");
}
static pthread_mutex_t cv_mutex=PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t cv=PTHREAD_COND_INITIALIZER;
static int ready;
static void *cv_worker(void *arg) {
    (void)arg;pthread_mutex_lock(&cv_mutex);
    while(!ready)pthread_cond_wait(&cv,&cv_mutex);
    puts("Condition variable notification received.");pthread_mutex_unlock(&cv_mutex);return NULL;
}
void condition_variable_demo(void) {
    pthread_t t;ready=0;
    if(pthread_create(&t,NULL,cv_worker,NULL)!=0){perror("pthread_create");return;}
    usleep(50000);pthread_mutex_lock(&cv_mutex);ready=1;pthread_cond_signal(&cv);pthread_mutex_unlock(&cv_mutex);pthread_join(t,NULL);
}

void deadlock_analysis_demo(void) {
    puts("Resource-allocation graph analysis (teaching scenario):");
    puts("P1 holds R1 and waits for R2.");
    puts("P2 holds R2 and waits for R1.");
    puts("Graph edges: R1 -> P1, P1 -> R2, R2 -> P2, P2 -> R1");
    puts("Cycle detected: P1 -> R2 -> P2 -> R1 -> P1");
    puts("Diagnosis: circular wait exists; this scenario is deadlock-prone.");
    puts("Prevention policy: acquire resources in a global order (R1 before R2).");
}
