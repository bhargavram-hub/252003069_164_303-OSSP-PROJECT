#ifndef SCHEDULER_H
#define SCHEDULER_H

#define MAX_PROCESSES 20
#define MAX_TIMELINE 10000
#define MAX_HISTORY 256

typedef enum { NEW, READY, RUNNING, WAITING, TERMINATED } ProcessState;

typedef struct {
    int pid, arrival_time, burst_time, priority;
    int completion_time, turnaround_time, waiting_time, response_time;
    int remaining_time, start_time, context_switches;
    int running_time, ready_time, blocked_time, io_remaining;
    int io_enabled, io_trigger, io_duration, io_done;
    ProcessState state;
    ProcessState history[MAX_HISTORY];
    int history_count;
} Process;

int input_processes(Process *p, int max);
void display_process_info(Process *p, int n);
void run_scheduler(Process *p, int n, int preemptive);
void create_process_demo(void);
void monitor_current_process(void);
void pipe_demo(void);
void fifo_demo(void);
void signal_demo(void);
void memory_management_demo(void);
void virtual_memory_demo(void);
void file_io_demo(void);
void buffered_io_demo(void);
void unbuffered_io_demo(void);
void mmap_demo(void);
void thread_demo(void);
void mutex_demo(void);
void semaphore_demo(void);
void condition_variable_demo(void);
void message_queue_demo(void);
void memory_leak_demo(void);
void deadlock_analysis_demo(void);
void event_log(const char *category, const char *message, int pid, int time);
void advanced_algorithm_lab(void);
void message_delivery_lab(void);
void banker_safety_lab(void);
void page_replacement_lab(void);
void export_metrics_lab(void);

#endif
