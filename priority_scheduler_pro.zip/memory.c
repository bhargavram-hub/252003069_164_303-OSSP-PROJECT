#include "scheduler.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/resource.h>

void memory_management_demo(void) {
    size_t n=8;
    int *a=malloc(n*sizeof(*a)),*b=calloc(n,sizeof(*b));
    if(!a||!b){perror("allocation");free(a);free(b);return;}
    for(size_t i=0;i<n;i++)a[i]=(int)(i*i);
    int *tmp=realloc(a,2*n*sizeof(*a));
    if(!tmp){perror("realloc");free(a);free(b);return;}
    a=tmp;for(size_t i=n;i<2*n;i++)a[i]=(int)i;
    printf("malloc/realloc: a[10]=%d; calloc initial value: b[0]=%d\n",a[10],b[0]);
    free(a);free(b);puts("All tracked allocations freed.");
}
void virtual_memory_demo(void) {
    struct rusage before,after;getrusage(RUSAGE_SELF,&before);
    size_t bytes=16*1024*1024;volatile unsigned char *p=malloc(bytes);
    if(!p){perror("malloc");return;}
    long page=sysconf(_SC_PAGESIZE);if(page<=0)page=4096;
    for(size_t i=0;i<bytes;i+=(size_t)page)p[i]=1;
    getrusage(RUSAGE_SELF,&after);
    printf("Touched %zu bytes; page size=%ld bytes\n",bytes,page);
    printf("Minor faults: %ld -> %ld; major faults: %ld -> %ld\n",before.ru_minflt,after.ru_minflt,before.ru_majflt,after.ru_majflt);
    free((void *)p);
}

/* A controlled teaching demo: records allocations and detects one intentionally
   unfreed block, then frees it after reporting to avoid leaking the demo itself. */
void memory_leak_demo(void) {
    struct Allocation { void *ptr; size_t bytes; const char *label; int freed; };
    struct Allocation records[4] = {{0}};
    records[0].bytes=64; records[0].label="process-table";
    records[0].ptr=malloc(records[0].bytes);
    records[1].bytes=128; records[1].label="message-buffer";
    records[1].ptr=malloc(records[1].bytes);
    records[2].bytes=256; records[2].label="temporary-cache";
    records[2].ptr=malloc(records[2].bytes);
    for(int i=0;i<3;i++) if(!records[i].ptr) {
        perror("malloc"); for(int j=0;j<3;j++) free(records[j].ptr); return;
    }
    free(records[0].ptr); records[0].freed=1;
    free(records[1].ptr); records[1].freed=1;
    size_t outstanding=0; int leaks=0;
    puts("Allocation audit:");
    for(int i=0;i<3;i++) {
        printf("  %-16s bytes=%zu status=%s\n",records[i].label,records[i].bytes,
               records[i].freed?"FREED":"OUTSTANDING");
        if(!records[i].freed) { outstanding+=records[i].bytes; leaks++; }
    }
    printf("Leak report: outstanding blocks=%d, outstanding bytes=%zu\n",leaks,outstanding);
    puts("Cleanup phase: releasing intentionally outstanding test allocation.");
    free(records[2].ptr);
}
