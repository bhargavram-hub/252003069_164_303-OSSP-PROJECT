#include "scheduler.h"
#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include <string.h>

static const char *path="/tmp/priority_scheduler_demo.txt";
void file_io_demo(void) {
    int fd=open(path,O_CREAT|O_TRUNC|O_WRONLY,0644);
    if(fd<0){perror("open");return;}
    const char *m="Linux file descriptor demonstration\n";
    if (write(fd, m, strlen(m)) < 0) perror("write");
    close(fd);
    struct stat st;if(stat(path,&st)==0)printf("File size=%lld bytes, permissions=%o\n",(long long)st.st_size,st.st_mode&0777);
    fd=open(path,O_RDONLY);if(fd>=0){char b[256]={0};ssize_t n=read(fd,b,sizeof(b)-1);if(n>0)printf("Read: %s",b);close(fd);}
}
void buffered_io_demo(void) {
    FILE *f=fopen(path,"w");if(!f){perror("fopen");return;}
    fprintf(f,"Buffered output using fprintf()\n");fclose(f);
    f=fopen(path,"r");if(!f){perror("fopen");return;}char b[256];if(fgets(b,sizeof(b),f))printf("%s",b);fclose(f);
}
void unbuffered_io_demo(void) {
    int fd=open(path,O_CREAT|O_TRUNC|O_WRONLY,0644);if(fd<0){perror("open");return;}
    const char *m="Unbuffered write() system call\n";ssize_t n=write(fd,m,strlen(m));printf("write() returned %ld bytes.\n",(long)n);close(fd);
}
void mmap_demo(void) {
    int fd=open(path,O_CREAT|O_RDWR|O_TRUNC,0644);if(fd<0){perror("open");return;}
    const char *m="Memory-mapped file demonstration";size_t len=strlen(m)+1;
    if(ftruncate(fd,(off_t)len)<0){perror("ftruncate");close(fd);return;}
    char *p=mmap(NULL,len,PROT_READ|PROT_WRITE,MAP_SHARED,fd,0);
    if(p==MAP_FAILED){perror("mmap");close(fd);return;}
    memcpy(p,m,len);if(msync(p,len,MS_SYNC)<0)perror("msync");printf("mmap wrote: %s\n",p);munmap(p,len);close(fd);
}
