#include "scheduler.h"
#include <stdio.h>
#include <string.h>

static int timeline[MAX_TIMELINE];
static int timeline_len;

static const char *state_name(ProcessState s) {
    switch (s) {
        case NEW: return "NEW"; case READY: return "READY"; case RUNNING: return "RUNNING";
        case WAITING: return "WAITING"; case TERMINATED: return "TERMINATED";
    }
    return "UNKNOWN";
}
static void history_add(Process *p, ProcessState s) {
    if (p->state != s) {
        p->state = s;
        if (p->history_count < MAX_HISTORY) p->history[p->history_count++] = s;
    }
}
static int effective_priority(const Process *p) {
    int v = p->priority - p->ready_time / 3;
    return v < 0 ? 0 : v;
}
static void reset(Process *p, int n) {
    for (int i=0;i<n;i++) {
        p[i].completion_time=p[i].turnaround_time=p[i].waiting_time=p[i].response_time=0;
        p[i].remaining_time=p[i].burst_time;
        p[i].start_time=-1; p[i].context_switches=0;
        p[i].running_time=p[i].ready_time=p[i].blocked_time=p[i].io_remaining=0;
        p[i].io_done=0; p[i].state=NEW; p[i].history_count=0;
        p[i].history[p[i].history_count++]=NEW;
    }
    timeline_len=0;
}
static void arrivals(Process *p,int n,int t) {
    for(int i=0;i<n;i++)
        if(p[i].state==NEW && p[i].arrival_time<=t) {
            history_add(&p[i],READY);
            event_log("STATE", "NEW -> READY (arrived)", p[i].pid, t);
        }
}
static int select_ready(Process *p,int n,int preemptive) {
    int best=-1;
    for(int i=0;i<n;i++) {
        if(p[i].state!=READY || p[i].remaining_time<=0) continue;
        if(best<0) { best=i; continue; }
        int a=preemptive?effective_priority(&p[i]):p[i].priority;
        int b=preemptive?effective_priority(&p[best]):p[best].priority;
        if(a<b || (a==b && (p[i].arrival_time<p[best].arrival_time ||
           (p[i].arrival_time==p[best].arrival_time && p[i].pid<p[best].pid)))) best=i;
    }
    return best;
}
static void tick_io(Process *p,int n) {
    for(int i=0;i<n;i++) if(p[i].state==WAITING) {
        if(p[i].io_remaining>0) p[i].io_remaining--;
        p[i].blocked_time++;
        if(p[i].io_remaining<=0) {
            history_add(&p[i],READY);
            event_log("IO", "I/O complete; process returned to READY queue", p[i].pid, -1);
        }
    }
}
static void gantt(Process *p) {
    puts("\n---------------- GANTT CHART ----------------");
    if(!timeline_len) { puts("No timeline recorded."); return; }
    int i=0;
    printf("|");
    while(i<timeline_len) {
        int id=timeline[i], j=i+1;
        while(j<timeline_len && timeline[j]==id) j++;
        if(id<0) printf(" IDLE |");
        else printf(" P%d |",p[id].pid);
        i=j;
    }
    printf("\n0");
    i=0;
    while(i<timeline_len) {
        int id=timeline[i], j=i+1;
        while(j<timeline_len && timeline[j]==id) j++;
        printf("%6d",j);
        i=j;
    }
    puts("\nTime labels mark the end of each segment.");
}
void run_scheduler(Process *p,int n,int preemptive) {
    reset(p,n);
    if (preemptive) {
        FILE *log = fopen("scheduler_events.log", "w");
        if (log) { fputs("PRIORITY SCHEDULER EVENT LOG\n", log); fclose(log); }
    }
    int t=0, done=0, busy=0, switches=0, previous=-1;
    while(done<n && timeline_len<MAX_TIMELINE) {
        arrivals(p,n,t);
        tick_io(p,n);
        int s=select_ready(p,n,preemptive);
        if(s<0) {
            timeline[timeline_len++]=-1; t++; previous=-1;
            continue;
        }
        if(previous>=0 && previous!=s) { switches++; p[s].context_switches++; }
        if(p[s].start_time<0) p[s].start_time=t;
        {
            char msg[128];
            snprintf(msg, sizeof(msg), "Dispatched; effective priority=%d", preemptive ? effective_priority(&p[s]) : p[s].priority);
            event_log("DISPATCH", msg, p[s].pid, t);
        }
        history_add(&p[s],RUNNING);
        timeline[timeline_len++]=s;
        p[s].remaining_time--; p[s].running_time++; busy++; t++;
        for(int i=0;i<n;i++) if(i!=s && p[i].state==READY) p[i].ready_time++;

        int cpu_used=p[s].burst_time-p[s].remaining_time;
        if(p[s].io_enabled && !p[s].io_done && cpu_used==p[s].io_trigger && p[s].remaining_time>0) {
            p[s].io_done=1; p[s].io_remaining=p[s].io_duration;
            history_add(&p[s],WAITING);
            event_log("BLOCK", "Process blocked for simulated I/O", p[s].pid, t);
            previous=-1;
        } else if(p[s].remaining_time==0) {
            p[s].completion_time=t;
            p[s].turnaround_time=t-p[s].arrival_time;
            history_add(&p[s],TERMINATED);
            event_log("EXIT", "Process terminated", p[s].pid, t);
            done++; previous=-1;
        } else if(preemptive) {
            history_add(&p[s],READY);
            previous=s;
        } else {
            /* Finish current process without preemption, but honor its one I/O event. */
            previous=s;
            while(p[s].remaining_time>0 && timeline_len<MAX_TIMELINE) {
                tick_io(p,n);
                if(p[s].io_enabled && !p[s].io_done &&
                   p[s].burst_time-p[s].remaining_time==p[s].io_trigger) {
                    p[s].io_done=1; p[s].io_remaining=p[s].io_duration;
                    history_add(&p[s],WAITING); previous=-1;
                    while(p[s].state==WAITING && timeline_len<MAX_TIMELINE) {
                        timeline[timeline_len++]=-1; t++;
                        tick_io(p,n);
                        for(int k=0;k<n;k++) if(k!=s && p[k].state==READY) p[k].ready_time++;
                    }
                    if(p[s].state==READY) history_add(&p[s],RUNNING);
                    continue;
                }
                timeline[timeline_len++]=s;
                p[s].remaining_time--; p[s].running_time++; busy++; t++;
                for(int k=0;k<n;k++) if(k!=s && p[k].state==READY) p[k].ready_time++;
            }
            if(p[s].remaining_time==0) {
                p[s].completion_time=t; p[s].turnaround_time=t-p[s].arrival_time;
                history_add(&p[s],TERMINATED); done++;
            }
            previous=-1;
        }
    }
    if(done<n) puts("Warning: timeline limit reached.");
    double wt=0,tat=0,rt=0;
    puts("\n---------------- SCHEDULING RESULTS ----------------");
    printf("%-5s %4s %4s %4s %4s %4s %4s %4s\n","PID","AT","BT","PRI","CT","TAT","WT","RT");
    for(int i=0;i<n;i++) {
        p[i].turnaround_time=p[i].completion_time-p[i].arrival_time;
        p[i].waiting_time=p[i].turnaround_time-p[i].burst_time-p[i].blocked_time;
        if(p[i].waiting_time<0) p[i].waiting_time=0;
        p[i].response_time=p[i].start_time-p[i].arrival_time;
        wt+=p[i].waiting_time; tat+=p[i].turnaround_time; rt+=p[i].response_time;
        printf("P%-4d %4d %4d %4d %4d %4d %4d %4d\n",p[i].pid,p[i].arrival_time,p[i].burst_time,p[i].priority,p[i].completion_time,p[i].turnaround_time,p[i].waiting_time,p[i].response_time);
    }
    printf("Average waiting time    : %.2f\n",wt/n);
    printf("Average turnaround time : %.2f\n",tat/n);
    printf("Average response time   : %.2f\n",rt/n);
    printf("CPU utilization         : %.2f%%\n",t?100.0*busy/t:0.0);
    printf("Throughput              : %.3f processes/unit time\n",t?(double)n/t:0.0);
    printf("Context switches        : %d\n",switches);
    puts("\nPROCESS STATES AND HISTORY");
    for(int i=0;i<n;i++) {
        printf("P%d (%s): ",p[i].pid,state_name(p[i].state));
        for(int j=0;j<p[i].history_count;j++)
            printf("%s%s",j?" -> ":"",state_name(p[i].history[j]));
        putchar('\n');
    }
    gantt(p);
}
