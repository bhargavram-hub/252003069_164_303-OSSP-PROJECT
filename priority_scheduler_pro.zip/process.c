#include "scheduler.h"
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>

int input_processes(Process *p, int max) {
    int n;
    printf("\nEnter number of processes (1-%d): ", max);
    if (scanf("%d", &n) != 1 || n < 1 || n > max) {
        puts("Invalid process count.");
        return 0;
    }

    for (int i = 0; i < n; i++) {
        memset(&p[i], 0, sizeof(p[i]));
        p[i].pid = i + 1;
        p[i].state = NEW;
        p[i].start_time = -1;
        printf("\n------------ PROCESS P%d ------------\n", p[i].pid);
        printf("Arrival Time: ");
        if (scanf("%d", &p[i].arrival_time) != 1 || p[i].arrival_time < 0) {
            puts("Arrival time must be a non-negative integer."); return 0;
        }
        printf("Burst Time: ");
        if (scanf("%d", &p[i].burst_time) != 1 || p[i].burst_time <= 0) {
            puts("Burst time must be a positive integer."); return 0;
        }
        printf("Priority (smaller number = higher priority): ");
        if (scanf("%d", &p[i].priority) != 1 || p[i].priority < 0) {
            puts("Priority must be a non-negative integer."); return 0;
        }
        printf("Enable simulated I/O? (1=yes, 0=no): ");
        if (scanf("%d", &p[i].io_enabled) != 1 ||
            (p[i].io_enabled != 0 && p[i].io_enabled != 1)) {
            puts("Enter 1 or 0."); return 0;
        }
        if (p[i].io_enabled) {
            printf("CPU time before I/O (1 to %d): ", p[i].burst_time - 1);
            if (scanf("%d", &p[i].io_trigger) != 1 ||
                p[i].io_trigger < 1 || p[i].io_trigger >= p[i].burst_time) {
                puts("I/O trigger must be less than burst time and at least 1."); return 0;
            }
            printf("I/O wait duration (>0): ");
            if (scanf("%d", &p[i].io_duration) != 1 || p[i].io_duration <= 0) {
                puts("I/O duration must be positive."); return 0;
            }
        }
        p[i].remaining_time = p[i].burst_time;
    }
    return n;
}

void display_process_info(Process *p, int n) {
    puts("\n---------------- PROCESS INFORMATION ----------------");
    printf("%-6s %-5s %-5s %-5s %-5s\n", "PID", "AT", "BT", "PRI", "I/O");
    for (int i = 0; i < n; i++)
        printf("P%-5d %-5d %-5d %-5d %-5s\n", p[i].pid, p[i].arrival_time,
               p[i].burst_time, p[i].priority, p[i].io_enabled ? "YES" : "NO");
}

void create_process_demo(void) {
    pid_t pid = fork();
    if (pid < 0) { perror("fork"); return; }
    if (pid == 0) {
        dprintf(STDOUT_FILENO, "Child process: PID=%ld, parent PID=%ld\n",
                (long)getpid(), (long)getppid());
        _exit(0);
    }
    printf("Parent process: PID=%ld, child PID=%ld\n", (long)getpid(), (long)pid);
    int status;
    if (waitpid(pid, &status, 0) < 0) perror("waitpid");
    else puts("Child process successfully reaped using waitpid().");
}

void monitor_current_process(void) {
    char path[128], line[256];
    snprintf(path, sizeof(path), "/proc/%ld/status", (long)getpid());
    FILE *f = fopen(path, "r");
    if (!f) { perror("open /proc status"); return; }
    const char *keys[] = {"Name:", "State:", "Pid:", "PPid:", "Threads:", "VmSize:", "VmRSS:"};
    while (fgets(line, sizeof(line), f))
        for (size_t i = 0; i < sizeof(keys)/sizeof(keys[0]); i++)
            if (strncmp(line, keys[i], strlen(keys[i])) == 0) fputs(line, stdout);
    fclose(f);
}
