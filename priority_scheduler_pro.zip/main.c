#include "scheduler.h"
#include <stdio.h>

int main(void) {
    Process processes[MAX_PROCESSES];
    puts("\n====================================================");
    puts(" LINUX-BASED PRIORITY PROCESS SCHEDULING AND MANAGEMENT");
    puts(" Advanced automated demonstration");
    puts("====================================================");

    int n = input_processes(processes, MAX_PROCESSES);
    if (n <= 0) {
        puts("No valid process data supplied. Exiting.");
        return 1;
    }
    display_process_info(processes, n);

    puts("\n[1] PREEMPTIVE PRIORITY SCHEDULING, AGING, I/O BLOCKING");
    run_scheduler(processes, n, 1);
    puts("\n[2] NON-PREEMPTIVE PRIORITY SCHEDULING");
    run_scheduler(processes, n, 0);

    puts("\n[3] REAL PROCESS CREATION: fork() / waitpid()");
    create_process_demo();
    puts("\n[4] LINUX PROCESS MONITORING: /proc");
    monitor_current_process();
    puts("\n[5] ANONYMOUS PIPE IPC");
    pipe_demo();
    puts("\n[6] NAMED FIFO IPC");
    fifo_demo();
    puts("\n[7] SIGNAL DELIVERY");
    signal_demo();
    puts("\n[8] DYNAMIC ALLOCATION / REALLOCATION / CLEANUP");
    memory_management_demo();
    puts("\n[9] CONTROLLED MEMORY-LEAK AUDIT");
    memory_leak_demo();
    puts("\n[10] VIRTUAL MEMORY AND PAGE-FAULT OBSERVATION");
    virtual_memory_demo();
    puts("\n[11] FILE DESCRIPTORS AND METADATA");
    file_io_demo();
    puts("\n[12] BUFFERED FILE I/O");
    buffered_io_demo();
    puts("\n[13] UNBUFFERED FILE I/O");
    unbuffered_io_demo();
    puts("\n[14] MEMORY-MAPPED FILE");
    mmap_demo();
    puts("\n[15] THREADS AND MUTEX");
    thread_demo();
    puts("\n[16] BOUNDED MESSAGE QUEUE / WAITING / DELIVERY");
    message_queue_demo();
    puts("\n[17] SEMAPHORE SYNCHRONIZATION");
    semaphore_demo();
    puts("\n[18] CONDITION VARIABLE");
    condition_variable_demo();
    puts("\n[19] DEADLOCK CYCLE ANALYSIS");
    deadlock_analysis_demo();

    puts("\nEvent log written to scheduler_events.log");
    puts("====================================================");
    puts(" ALL DEMONSTRATIONS FINISHED");
    puts("====================================================");
    return 0;
}
