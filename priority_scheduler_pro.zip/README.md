# Priority Scheduler — Pro Edition

## Build
```bash
make clean && make
./priority_scheduler
```

The program asks for process arrival time, burst time, priority, and optional simulated I/O. It then runs preemptive and non-preemptive scheduling and automated OS demonstrations.

## Advanced labs
- Scheduler lifecycle, ready queue aging, simulated I/O blocking, Gantt chart, metrics and event log.
- FCFS and Round Robin comparison workload with waiting, turnaround and response time.
- Message-loss simulation with sequence IDs, retry, acknowledgement and summary counters.
- Banker's algorithm safe-sequence analysis.
- FIFO and LRU page-replacement comparison on a fixed reference string.
- Allocation audit/leak report and virtual memory page-fault observations.
- Linux fork/waitpid, /proc, anonymous pipe, FIFO, signals, file operations, mmap, pthreads, mutex, semaphore and condition variable.
- Exports `experiment_summary.csv` and `scheduler_events.log`.

Important: scheduling, message loss/retry, and paging are educational simulations; the Linux system-call demos use real OS facilities. Run your own test cases and verify the reported results before submission.
